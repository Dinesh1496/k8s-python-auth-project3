from fastapi import FastAPI
import requests

app = FastAPI()

@app.get("/list")
def list_tasks():
    return {
        "tasks": [
            "Task 1",
            "Task 2",
            "Task 3"
        ]
    }