from fastapi import FastAPI
import requests

app = FastAPI()

AUTH_SERVICE_URL = "http://auth-api:8000"   # Kubernetes Service name

@app.get("/profile")
def profile(username: str):
    auth_response = requests.get(f"{AUTH_SERVICE_URL}/login", params={"username": username})
    token = auth_response.json().get("token")
    return {
        "user": username,
        "token_received_from_auth": token
    }

@app.get("/update_profile")
def update_profile():
    return {"message": "User profile updated"}

@app.get("/delete_profile")
def delete_profile():
    return {"message": "User profile deleted"}

@app.get("/change_password")
def change_password():
    return {"message": "Password changed"}

@app.get("/reset_password")
def reset_password():
    return {"message": "Password reset"}

@app.get("/verify_email")
def verify_email():
    return {"message": "Email verified"}

