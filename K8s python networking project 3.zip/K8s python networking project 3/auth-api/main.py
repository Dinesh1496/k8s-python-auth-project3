from fastapi import FastAPI

app = FastAPI()

@app.get("/login")
def login(username: str):
    return {"message": f"User {username} logged in", "token": "dummy-token"}

@app.get("/logout")
def logout():
    return {"message": "User logged out"}

@app.get("/register")
def register(username: str, password: str):
    return {"message": f"User {username} registered"}

@app.get("/profile")
def profile():
    return {"message": "User profile accessed"}

@app.get("/update_profile")
def update_profile():
    return {"message": "User profile updated"}

@app.get("/delete_profile")
def delete_profile():
    return {"message": "User profile deleted"}

@app.get("/change_password")
def change_password():
    return {"message": "Password changed"}

@app.get("/reset_password")
def reset_password():
    return {"message": "Password reset"}

@app.get("/verify_email")
def verify_email():
    return {"message": "Email verified"}

@app.get("/resend_verification_email")
def resend_verification_email():
    return {"message": "Verification email resent"}

